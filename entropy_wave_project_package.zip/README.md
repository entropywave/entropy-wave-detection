# Entropy Wave Detection Preprint

This repository contains the initial preprint and LaTeX source for:

**Title:** Global Phase Coherence Drift as a Probe of Cosmological Entropy Fluctuations  
**Author:** Steve Pence  
**Date:** Spring 2025

## Description

This preprint outlines a proposed experiment using idle-mode superconducting qubits to detect entropy-relevant field fluctuations across globally distributed quantum systems. It defines an architecture for 5σ validation of correlated quantum coherence drift and proposes a new observational window into quantum gravity and vacuum structure.

## Files Included
- `entropy_wave_preprint.tex` – LaTeX source
- `LICENSE.txt` – Open license for collaboration and reuse
- `README.md` – Project overview and instructions

## Contact
For inquiries or collaboration: **entropywaves@protonmail.com**
